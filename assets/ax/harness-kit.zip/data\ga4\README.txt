이 폴더에는 GA4에서 내려받은 CSV를 넣습니다.
GA4 > Reports > 보고서 오른쪽 위 Share this report > Download File > Download CSV (Google 도움말의 영어 이름)
파일 이름 앞에 오늘 날짜를 붙여 넣으세요(예: 2026-11-12-events.csv). 작업은 이름순으로 가장 마지막 파일을 읽습니다.
0000-practice-sample.csv는 연습용 가상 숫자입니다. 날짜 이름의 파일이 있으면 그 파일이 먼저 읽힙니다.
