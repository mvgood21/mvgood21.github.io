﻿param(
    [Parameter(Mandatory = $true)][string]$Name,
    [string]$Folder = '\my-harness\'
)
# 등록한 예약을 지운다. 키트 폴더의 파일은 그대로 둔다. 없는 예약이면 오류로 끝난다.
$ErrorActionPreference = 'Stop'
Unregister-ScheduledTask -TaskPath $Folder -TaskName $Name -Confirm:$false -ErrorAction Stop
Write-Output "$Name 예약을 지웠습니다."
