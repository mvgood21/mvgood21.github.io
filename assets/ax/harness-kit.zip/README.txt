# 하네스 키트 (SugarMount AX 노트 Windows 하네스 연재용)

이 폴더를 내 사용자 폴더 아래 harness 폴더로 풀어 쓰세요. 예: C:\Users\(내 이름)\harness

- run-job.ps1 : 작업 하나를 실행합니다.      예) .\run-job.ps1 -Name hello
- register-job.ps1 : 매일 같은 시각에 예약합니다. 예) .\register-job.ps1 -Name hello -At 09:05
- remove-job.ps1 : 예약을 지웁니다.            예) .\remove-job.ps1 -Name hello
- status.ps1 : 작업별 마지막 결과와 다음 예약을 봅니다.
- status.cmd : 두 번 클릭하면 status.ps1 표를 보여 주고 아무 키나 누를 때까지 기다립니다.
- prompts\en\ : 영어 지시문. 쓰려면 jobs\<작업>.json의 "prompt"를 "prompts/en/<작업>.md"로 바꿉니다.
- jobs\ : 작업 정의(언제, 어떤 모델, 허용 도구, 시간 한도)
- prompts\ : 작업마다 Claude에게 주는 지시문
- data\ : 작업이 읽는 자료(연습용 가상 파일이 들어 있습니다)
- reports\ : 작업이 끝나면 날짜별 보고서와 가장 최근 보고서 사본(latest-<작업>.md)이 생깁니다.
- logs\, state\ : 실행 기록과 마지막 결과

PowerShell에서 스크립트를 처음 실행할 때 막히면 연재 6편을 보세요.
