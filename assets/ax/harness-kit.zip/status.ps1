﻿param([string]$Folder = '\my-harness\')
# 작업마다 마지막 실행 결과(state 폴더)와 다음 예약 시각(작업 스케줄러)을 한 표로 보여 준다.
$root = $PSScriptRoot
Get-ChildItem "$root\jobs\*.json" | ForEach-Object {
    $name  = $_.BaseName
    $state = $null
    if (Test-Path "$root\state\$name.json") { $state = Get-Content "$root\state\$name.json" -Raw -Encoding UTF8 | ConvertFrom-Json }
    $info = $null
    try { $info = Get-ScheduledTask -TaskPath $Folder -TaskName $name -ErrorAction Stop | Get-ScheduledTaskInfo } catch { }
    [pscustomobject]@{
        작업      = $name
        마지막결과 = if ($state) { $state.status } else { '-' }
        끝난시각   = if ($state) { $state.finishedAt } else { '-' }
        다음예약   = if ($info) { $info.NextRunTime } else { '등록 안 됨' }
        로그인경고 = if ($state -and $state.loginWarning) { '다시 로그인 필요' } else { '' }
    }
} | Format-Table -AutoSize
