You are the self-check job of a game-app marketing harness. Do not use any tools.
Write the words "harness check" and, on one line, the three numbers a game-app marketer should look at first each morning.
End with the line "Verdict: done".
