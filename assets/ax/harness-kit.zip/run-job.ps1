﻿param([Parameter(Mandatory = $true)][string]$Name)
# 작업 하나를 실행한다: 작업 정의를 읽고, 겹침을 막고, 시간 한도를 걸고, 로그와 보고서를 남긴다.
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$job  = Get-Content "$root\jobs\$Name.json" -Raw -Encoding UTF8 | ConvertFrom-Json
New-Item -ItemType Directory -Force "$root\logs", "$root\state", "$root\reports" | Out-Null
$log  = "$root\logs\$Name.log"
function Write-Log($msg) { Add-Content -Path $log -Value "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $msg" -Encoding UTF8 }

# 1) 같은 작업이 아직 돌고 있으면 건너뛴다
$mutex = New-Object System.Threading.Mutex($false, "Global\my-harness-$Name")
if (-not $mutex.WaitOne(0)) { Write-Log '이전 실행이 아직 돌고 있어 건너뜀'; exit 5 }

try {
    # 2) 전용 설정 폴더(로그인 정보가 대화용 Claude와 섞이지 않게)
    if ($job.configDir) { $env:CLAUDE_CONFIG_DIR = $job.configDir.Replace('~', $HOME) }

    # 3) claude -p 인자: 지시문은 인자가 아니라 표준 입력으로 넣는다
    $claudeArgs = @('-p', '--model', $job.model)
    if ($job.allowedTools -and $job.allowedTools.Count -gt 0) {
        $claudeArgs += @('--allowedTools', ('"' + ($job.allowedTools -join ',') + '"'))
    }
    $promptFile = "$root\$($job.prompt)"
    $outFile    = "$env:TEMP\my-harness-$Name.out"
    $cmdLine    = 'claude ' + ($claudeArgs -join ' ') + " < `"$promptFile`" > `"$outFile`" 2>&1"

    Write-Log "시작 model=$($job.model) timeout=$($job.timeoutSeconds)s"
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $loginWarning = $false
    $p  = Start-Process -FilePath 'cmd.exe' -ArgumentList '/c', $cmdLine -WorkingDirectory $root -WindowStyle Hidden -PassThru

    # 4) 시간 한도: 넘으면 claude와 그 자식 프로세스까지 끈다
    if (-not $p.WaitForExit([int]$job.timeoutSeconds * 1000)) {
        & taskkill.exe /PID $p.Id /T /F | Out-Null
        $status = 'timeout'; $code = 1
    } else {
        $code = $p.ExitCode
        $status = if ($code -eq 0) { 'ok' } else { 'error' }
    }
    if (Test-Path $outFile) {
        $answer = Get-Content $outFile -Encoding UTF8
        $answer | Add-Content -Path $log -Encoding UTF8
        # 로그인 만료 예고가 나오면 따로 적어 둔다(전용 설정 폴더에서 다시 로그인해야 한다)
        $loginWarning = [bool]($answer | Select-String -Pattern 'sign-in ends|login expires' -Quiet)
        if ($loginWarning) { Write-Log '주의: Claude 로그인 만료 예고가 나왔습니다. 전용 설정 폴더에서 다시 로그인하세요' }
        # 5) 정상으로 끝난 답만 날짜별 보고서 파일로 남긴다(메모장으로 열어 읽는다). 경고 줄은 로그에만 둔다
        if ($status -eq 'ok') {
            $report = "$root\reports\$(Get-Date -Format 'yyyy-MM-dd')-$Name.md"
            $answer | Where-Object { $_ -notmatch '^Warning: this sign-in ends' } | Set-Content -Path $report -Encoding UTF8
            # 날짜를 몰라도 열 수 있게 가장 최근 보고서를 latest-<작업>.md로도 둔다
            Copy-Item $report "$root\reports\latest-$Name.md" -Force
        }
        Remove-Item $outFile
    }
    Write-Log ("종료 status={0} exit={1} ({2:N0}s)" -f $status, $code, $sw.Elapsed.TotalSeconds)

    # 6) 마지막 결과를 상태 파일로 남긴다(status.ps1이 이 파일을 읽는다)
    @{ job = $Name; status = $status; exitCode = $code; loginWarning = [bool]$loginWarning; finishedAt = (Get-Date).ToString('s') } |
        ConvertTo-Json | Set-Content -Path "$root\state\$Name.json" -Encoding UTF8
    # 7) 화면에도 한 줄 남긴다
    $msg = "끝: $Name status=$status exit=$code"
    if ($status -eq 'ok') { $msg += " 보고서 reports\latest-$Name.md" } else { $msg += " (logs\$Name.log 를 보세요)" }
    if ($loginWarning) { $msg += ' / 로그인 만료 예고 있음' }
    Write-Output $msg
    exit $code
}
finally {
    $mutex.ReleaseMutex()
}
