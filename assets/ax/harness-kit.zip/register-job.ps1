﻿param(
    [Parameter(Mandatory = $true)][string]$Name,
    [Parameter(Mandatory = $true)][string]$At,
    [string]$Folder = '\my-harness\'
)
# 작업 하나를 Windows 작업 스케줄러에 "매일 같은 시각"으로 등록한다. 같은 이름이 있으면 덮어쓴다.
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
if (-not (Test-Path "$root\jobs\$Name.json")) { throw "jobs\$Name.json 파일이 없습니다. 작업 이름을 확인하세요." }
$job = Get-Content "$root\jobs\$Name.json" -Raw -Encoding UTF8 | ConvertFrom-Json
# 스케줄러의 실행 한도: 작업 카드의 시간 한도보다 10분 길게, 최소 1시간
$limitMinutes = [Math]::Max(60, [Math]::Ceiling([int]$job.timeoutSeconds / 60) + 10)

$action = New-ScheduledTaskAction -Execute 'powershell.exe' `
    -Argument "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$root\run-job.ps1`" -Name $Name" `
    -WorkingDirectory $root
$trigger = New-ScheduledTaskTrigger -Daily -At $At
# 놓친 회차는 PC가 켜진 뒤 한 번 실행, 노트북 배터리에서도 실행, 겹치면 새 회차를 버림, 실행 한도를 넘으면 끔
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
    -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes $limitMinutes)
# 내가 로그온해 있는 동안 내 권한(관리자 아님)으로 실행: 비밀번호를 저장하지 않는다
$principal = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -LogonType Interactive -RunLevel Limited

Register-ScheduledTask -TaskPath $Folder -TaskName $Name -Action $action -Trigger $trigger `
    -Settings $settings -Principal $principal -Force | Out-Null
Get-ScheduledTask -TaskPath $Folder -TaskName $Name | Get-ScheduledTaskInfo |
    Select-Object TaskName, NextRunTime | Format-List
